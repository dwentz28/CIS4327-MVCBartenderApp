﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BartenderApp.Models;

namespace BartenderApp.Controllers
{
    public class BeverageOrdersController : Controller
    {
        private BartenderAppDBEntities db = new BartenderAppDBEntities();

        // GET: BeverageOrders
        public ActionResult Index()
        {
            var beverageOrders = db.BeverageOrders.Include(b => b.Beverage);
            return View(beverageOrders.ToList());
        }

        // GET: BeverageOrders/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BeverageOrder beverageOrder = db.BeverageOrders.Find(id);
            if (beverageOrder == null)
            {
                return HttpNotFound();
            }
            return View(beverageOrder);
        }

        // GET: BeverageOrders/Create
        public ActionResult Create()
        {
            ViewBag.Beverage_Id = new SelectList(db.Beverages, "Beverage_Id", "Beverage_Name");
            return View();
        }

        // POST: BeverageOrders/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "BevOrder_Id,BevOrder_Status,Beverage_Id,BevOrder_CustName,BevOrder_Details")] BeverageOrder beverageOrder)
        {
            if (ModelState.IsValid)
            {
                db.BeverageOrders.Add(beverageOrder);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            ViewBag.Beverage_Id = new SelectList(db.Beverages, "Beverage_Id", "Beverage_Name", beverageOrder.Beverage_Id);
            return View(beverageOrder);
        }

        // GET: BeverageOrders/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BeverageOrder beverageOrder = db.BeverageOrders.Find(id);
            if (beverageOrder == null)
            {
                return HttpNotFound();
            }
            ViewBag.Beverage_Id = new SelectList(db.Beverages, "Beverage_Id", "Beverage_Name", beverageOrder.Beverage_Id);
            return View(beverageOrder);
        }

        // POST: BeverageOrders/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "BevOrder_Id,BevOrder_Status,Beverage_Id,BevOrder_CustName,BevOrder_Details")] BeverageOrder beverageOrder)
        {
            if (ModelState.IsValid)
            {
                db.Entry(beverageOrder).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            ViewBag.Beverage_Id = new SelectList(db.Beverages, "Beverage_Id", "Beverage_Name", beverageOrder.Beverage_Id);
            return View(beverageOrder);
        }

        // GET: BeverageOrders/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            BeverageOrder beverageOrder = db.BeverageOrders.Find(id);
            if (beverageOrder == null)
            {
                return HttpNotFound();
            }
            return View(beverageOrder);
        }

        // POST: BeverageOrders/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            BeverageOrder beverageOrder = db.BeverageOrders.Find(id);
            db.BeverageOrders.Remove(beverageOrder);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
